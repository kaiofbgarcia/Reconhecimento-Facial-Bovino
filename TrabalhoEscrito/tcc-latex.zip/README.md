# tcc-cct-uenp
Modelo Latex para a construção do TCC do Centro de Ciências Tecnológicas da UENP.
